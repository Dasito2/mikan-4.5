package db

import (
	"context"
	"database/sql"
)

const getPromoCode = `SELECT * FROM promo_codes WHERE id = ?`
const getPromoCodeByCode = `SELECT * FROM promo_codes WHERE code = ?`
const listPromoCodes = `SELECT * FROM promo_codes WHERE deleted = 0 ORDER BY id DESC LIMIT ? OFFSET ?`
const countPromoCodes = `SELECT COUNT(*) FROM promo_codes WHERE deleted = 0`
const createPromoCode = `INSERT INTO promo_codes
(code,name,description,type,value,currency,starts_at,ends_at,max_uses,per_user_limit,discount_ttl,min_order,max_discount,tariff_ids,first_purchase_only,new_users_only,stackable,enabled,deleted,created_at,created_by)
VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,0,?,?) RETURNING *`
const updatePromoCode = `UPDATE promo_codes SET
code=?,name=?,description=?,type=?,value=?,currency=?,starts_at=?,ends_at=?,max_uses=?,per_user_limit=?,discount_ttl=?,min_order=?,max_discount=?,tariff_ids=?,first_purchase_only=?,new_users_only=?,stackable=?,enabled=? WHERE id=? AND deleted=0 RETURNING *`
const deletePromoCode = `UPDATE promo_codes SET deleted=1, enabled=0 WHERE id=? AND deleted=0`
const setPromoEnabled = `UPDATE promo_codes SET enabled=? WHERE id=? AND deleted=0`
const incrementPromoUse = `UPDATE promo_codes SET used_count=used_count+1 WHERE id=? AND (max_uses IS NULL OR used_count < max_uses) AND deleted=0 AND enabled=1`
const decrementPromoUse = `UPDATE promo_codes SET used_count=CASE WHEN used_count>0 THEN used_count-1 ELSE 0 END WHERE id=?`
const countPromoUser = `SELECT COUNT(*) FROM promo_redemptions WHERE promo_id=? AND ((user_id IS NOT NULL AND user_id=?) OR (user_id IS NULL AND tg_id=?)) AND status IN ('reserved','applied')`
const createPromoRedemption = `INSERT INTO promo_redemptions
(promo_id,user_id,tg_id,payment_id,status,redeemed_at,expires_at,days,bytes,discount_amount,original_amount,final_amount,currency,note)
VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?) RETURNING *`
const getPromoRedemption = `SELECT * FROM promo_redemptions WHERE id=?`
const getPromoRedemptionByPayment = `SELECT * FROM promo_redemptions WHERE payment_id=?`
const listPromoRedemptions = `SELECT * FROM promo_redemptions ORDER BY id DESC LIMIT ? OFFSET ?`
const countPromoRedemptions = `SELECT COUNT(*) FROM promo_redemptions`
const markPromoApplied = `UPDATE promo_redemptions SET status='applied', user_id=COALESCE(?,user_id) WHERE id=? AND status='reserved'`
const releasePromoRedemption = `UPDATE promo_redemptions SET status='released' WHERE id=? AND status='reserved'`
const releasePromoByPayment = `UPDATE promo_redemptions SET status='released' WHERE payment_id=? AND status='reserved'`
const promoStats = `SELECT COUNT(*), COALESCE(SUM(CASE WHEN status='applied' THEN days ELSE 0 END),0), COALESCE(SUM(CASE WHEN status='applied' THEN bytes ELSE 0 END),0), COALESCE(SUM(CASE WHEN status='applied' THEN discount_amount ELSE 0 END),0), COALESCE(SUM(CASE WHEN status='applied' AND payment_id IS NOT NULL THEN 1 ELSE 0 END),0) FROM promo_redemptions`

func (q *Queries) GetPromoCode(ctx context.Context, id int64) (PromoCode, error) {
	var x PromoCode
	err := q.db.QueryRowContext(ctx, getPromoCode, id).Scan(&x.ID, &x.Code, &x.Name, &x.Description, &x.Type, &x.Value, &x.Currency, &x.StartsAt, &x.EndsAt, &x.MaxUses, &x.UsedCount, &x.PerUserLimit, &x.DiscountTtl, &x.MinOrder, &x.MaxDiscount, &x.TariffIds, &x.FirstPurchaseOnly, &x.NewUsersOnly, &x.Stackable, &x.Enabled, &x.Deleted, &x.CreatedAt, &x.CreatedBy)
	return x, err
}
func (q *Queries) GetPromoCodeByCode(ctx context.Context, code string) (PromoCode, error) {
	var x PromoCode
	err := q.db.QueryRowContext(ctx, getPromoCodeByCode, code).Scan(&x.ID, &x.Code, &x.Name, &x.Description, &x.Type, &x.Value, &x.Currency, &x.StartsAt, &x.EndsAt, &x.MaxUses, &x.UsedCount, &x.PerUserLimit, &x.DiscountTtl, &x.MinOrder, &x.MaxDiscount, &x.TariffIds, &x.FirstPurchaseOnly, &x.NewUsersOnly, &x.Stackable, &x.Enabled, &x.Deleted, &x.CreatedAt, &x.CreatedBy)
	return x, err
}
func (q *Queries) ListPromoCodes(ctx context.Context, limit, offset int64) ([]PromoCode, error) {
	rows, err := q.db.QueryContext(ctx, listPromoCodes, limit, offset)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []PromoCode
	for rows.Next() {
		var x PromoCode
		if err := rows.Scan(&x.ID, &x.Code, &x.Name, &x.Description, &x.Type, &x.Value, &x.Currency, &x.StartsAt, &x.EndsAt, &x.MaxUses, &x.UsedCount, &x.PerUserLimit, &x.DiscountTtl, &x.MinOrder, &x.MaxDiscount, &x.TariffIds, &x.FirstPurchaseOnly, &x.NewUsersOnly, &x.Stackable, &x.Enabled, &x.Deleted, &x.CreatedAt, &x.CreatedBy); err != nil {
			return nil, err
		}
		out = append(out, x)
	}
	return out, rows.Err()
}
func (q *Queries) CountPromoCodes(ctx context.Context) (int64, error) {
	var n int64
	err := q.db.QueryRowContext(ctx, countPromoCodes).Scan(&n)
	return n, err
}

type CreatePromoCodeParams struct {
	Code, Name, Description, Type                       string
	Value                                               int64
	Currency                                            string
	StartsAt, EndsAt, MaxUses                           sql.NullInt64
	PerUserLimit, DiscountTtl, MinOrder, MaxDiscount    int64
	TariffIds                                           string
	FirstPurchaseOnly, NewUsersOnly, Stackable, Enabled int64
	CreatedAt                                           int64
	CreatedBy                                           sql.NullInt64
}

func (q *Queries) CreatePromoCode(ctx context.Context, p CreatePromoCodeParams) (PromoCode, error) {
	var x PromoCode
	err := q.db.QueryRowContext(ctx, createPromoCode, p.Code, p.Name, p.Description, p.Type, p.Value, p.Currency, p.StartsAt, p.EndsAt, p.MaxUses, p.PerUserLimit, p.DiscountTtl, p.MinOrder, p.MaxDiscount, p.TariffIds, p.FirstPurchaseOnly, p.NewUsersOnly, p.Stackable, p.Enabled, p.CreatedAt, p.CreatedBy).Scan(&x.ID, &x.Code, &x.Name, &x.Description, &x.Type, &x.Value, &x.Currency, &x.StartsAt, &x.EndsAt, &x.MaxUses, &x.UsedCount, &x.PerUserLimit, &x.DiscountTtl, &x.MinOrder, &x.MaxDiscount, &x.TariffIds, &x.FirstPurchaseOnly, &x.NewUsersOnly, &x.Stackable, &x.Enabled, &x.Deleted, &x.CreatedAt, &x.CreatedBy)
	return x, err
}

type UpdatePromoCodeParams struct {
	Code, Name, Description, Type                           string
	Value                                                   int64
	Currency                                                string
	StartsAt, EndsAt, MaxUses                               sql.NullInt64
	PerUserLimit, DiscountTtl, MinOrder, MaxDiscount        int64
	TariffIds                                               string
	FirstPurchaseOnly, NewUsersOnly, Stackable, Enabled, ID int64
}

func (q *Queries) UpdatePromoCode(ctx context.Context, p UpdatePromoCodeParams) (PromoCode, error) {
	var x PromoCode
	err := q.db.QueryRowContext(ctx, updatePromoCode, p.Code, p.Name, p.Description, p.Type, p.Value, p.Currency, p.StartsAt, p.EndsAt, p.MaxUses, p.PerUserLimit, p.DiscountTtl, p.MinOrder, p.MaxDiscount, p.TariffIds, p.FirstPurchaseOnly, p.NewUsersOnly, p.Stackable, p.Enabled, p.ID).Scan(&x.ID, &x.Code, &x.Name, &x.Description, &x.Type, &x.Value, &x.Currency, &x.StartsAt, &x.EndsAt, &x.MaxUses, &x.UsedCount, &x.PerUserLimit, &x.DiscountTtl, &x.MinOrder, &x.MaxDiscount, &x.TariffIds, &x.FirstPurchaseOnly, &x.NewUsersOnly, &x.Stackable, &x.Enabled, &x.Deleted, &x.CreatedAt, &x.CreatedBy)
	return x, err
}
func (q *Queries) DeletePromoCode(ctx context.Context, id int64) (int64, error) {
	r, e := q.db.ExecContext(ctx, deletePromoCode, id)
	if e != nil {
		return 0, e
	}
	n, _ := r.RowsAffected()
	return n, nil
}
func (q *Queries) SetPromoEnabled(ctx context.Context, id, enabled int64) (int64, error) {
	r, e := q.db.ExecContext(ctx, setPromoEnabled, enabled, id)
	if e != nil {
		return 0, e
	}
	n, _ := r.RowsAffected()
	return n, nil
}
func (q *Queries) IncrementPromoUse(ctx context.Context, id int64) (int64, error) {
	r, e := q.db.ExecContext(ctx, incrementPromoUse, id)
	if e != nil {
		return 0, e
	}
	n, _ := r.RowsAffected()
	return n, nil
}
func (q *Queries) DecrementPromoUse(ctx context.Context, id int64) (int64, error) {
	r, e := q.db.ExecContext(ctx, decrementPromoUse, id)
	if e != nil {
		return 0, e
	}
	n, _ := r.RowsAffected()
	return n, nil
}
func (q *Queries) CountUserPaidPayments(ctx context.Context, tgID int64) (int64, error) {
	var n int64
	err := q.db.QueryRowContext(ctx, `SELECT COUNT(*) FROM payments WHERE tg_id=? AND status IN ('paid','applied')`, tgID).Scan(&n)
	return n, err
}
func (q *Queries) CountPromoUser(ctx context.Context, promoID, userID, tgID int64) (int64, error) {
	var n int64
	err := q.db.QueryRowContext(ctx, countPromoUser, promoID, userID, tgID).Scan(&n)
	return n, err
}

type CreatePromoRedemptionParams struct {
	PromoID                                                  int64
	UserID                                                   sql.NullInt64
	TgID                                                     int64
	PaymentID                                                sql.NullInt64
	Status                                                   string
	RedeemedAt                                               int64
	ExpiresAt                                                sql.NullInt64
	Days, Bytes, DiscountAmount, OriginalAmount, FinalAmount int64
	Currency, Note                                           string
}

func (q *Queries) CreatePromoRedemption(ctx context.Context, p CreatePromoRedemptionParams) (PromoRedemption, error) {
	var x PromoRedemption
	err := q.db.QueryRowContext(ctx, createPromoRedemption, p.PromoID, p.UserID, p.TgID, p.PaymentID, p.Status, p.RedeemedAt, p.ExpiresAt, p.Days, p.Bytes, p.DiscountAmount, p.OriginalAmount, p.FinalAmount, p.Currency, p.Note).Scan(&x.ID, &x.PromoID, &x.UserID, &x.TgID, &x.PaymentID, &x.Status, &x.RedeemedAt, &x.ExpiresAt, &x.Days, &x.Bytes, &x.DiscountAmount, &x.OriginalAmount, &x.FinalAmount, &x.Currency, &x.Note)
	return x, err
}
func (q *Queries) GetPromoRedemption(ctx context.Context, id int64) (PromoRedemption, error) {
	var x PromoRedemption
	err := q.db.QueryRowContext(ctx, getPromoRedemption, id).Scan(&x.ID, &x.PromoID, &x.UserID, &x.TgID, &x.PaymentID, &x.Status, &x.RedeemedAt, &x.ExpiresAt, &x.Days, &x.Bytes, &x.DiscountAmount, &x.OriginalAmount, &x.FinalAmount, &x.Currency, &x.Note)
	return x, err
}
func (q *Queries) GetPromoRedemptionByPayment(ctx context.Context, paymentID int64) (PromoRedemption, error) {
	var x PromoRedemption
	err := q.db.QueryRowContext(ctx, getPromoRedemptionByPayment, paymentID).Scan(&x.ID, &x.PromoID, &x.UserID, &x.TgID, &x.PaymentID, &x.Status, &x.RedeemedAt, &x.ExpiresAt, &x.Days, &x.Bytes, &x.DiscountAmount, &x.OriginalAmount, &x.FinalAmount, &x.Currency, &x.Note)
	return x, err
}
func (q *Queries) ListPromoRedemptions(ctx context.Context, limit, offset int64) ([]PromoRedemption, error) {
	rows, err := q.db.QueryContext(ctx, listPromoRedemptions, limit, offset)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []PromoRedemption
	for rows.Next() {
		var x PromoRedemption
		if err := rows.Scan(&x.ID, &x.PromoID, &x.UserID, &x.TgID, &x.PaymentID, &x.Status, &x.RedeemedAt, &x.ExpiresAt, &x.Days, &x.Bytes, &x.DiscountAmount, &x.OriginalAmount, &x.FinalAmount, &x.Currency, &x.Note); err != nil {
			return nil, err
		}
		out = append(out, x)
	}
	return out, rows.Err()
}
func (q *Queries) CountPromoRedemptions(ctx context.Context) (int64, error) {
	var n int64
	err := q.db.QueryRowContext(ctx, countPromoRedemptions).Scan(&n)
	return n, err
}
func (q *Queries) MarkPromoApplied(ctx context.Context, userID sql.NullInt64, id int64) (int64, error) {
	r, e := q.db.ExecContext(ctx, markPromoApplied, userID, id)
	if e != nil {
		return 0, e
	}
	n, _ := r.RowsAffected()
	return n, nil
}
func (q *Queries) ReleasePromoRedemption(ctx context.Context, id int64) (int64, error) {
	r, e := q.db.ExecContext(ctx, releasePromoRedemption, id)
	if e != nil {
		return 0, e
	}
	n, _ := r.RowsAffected()
	return n, nil
}
func (q *Queries) ReleasePromoByPayment(ctx context.Context, paymentID int64) (int64, error) {
	r, e := q.db.ExecContext(ctx, releasePromoByPayment, paymentID)
	if e != nil {
		return 0, e
	}
	n, _ := r.RowsAffected()
	return n, nil
}

type PromoStats struct{ Count, Days, Bytes, Discounts, DiscountOrders int64 }

func (q *Queries) PromoStats(ctx context.Context) (PromoStats, error) {
	var x PromoStats
	err := q.db.QueryRowContext(ctx, promoStats).Scan(&x.Count, &x.Days, &x.Bytes, &x.Discounts, &x.DiscountOrders)
	return x, err
}

func (q *Queries) ListExpiredPromoPayments(ctx context.Context, before int64) ([]int64, error) {
	rows, err := q.db.QueryContext(ctx, `SELECT DISTINCT p.id FROM payments p JOIN promo_redemptions r ON r.payment_id=p.id WHERE p.status='expired' AND p.created_at < ? AND r.status='reserved'`, before)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []int64
	for rows.Next() {
		var id int64
		if err := rows.Scan(&id); err != nil {
			return nil, err
		}
		out = append(out, id)
	}
	return out, rows.Err()
}

func (q *Queries) ListPromoRedemptionsByTg(ctx context.Context, tgID int64, limit int64) ([]PromoRedemption, error) {
	rows, err := q.db.QueryContext(ctx, `SELECT * FROM promo_redemptions WHERE tg_id=? AND status='applied' ORDER BY id DESC LIMIT ?`, tgID, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []PromoRedemption
	for rows.Next() {
		var x PromoRedemption
		if err := rows.Scan(&x.ID, &x.PromoID, &x.UserID, &x.TgID, &x.PaymentID, &x.Status, &x.RedeemedAt, &x.ExpiresAt, &x.Days, &x.Bytes, &x.DiscountAmount, &x.OriginalAmount, &x.FinalAmount, &x.Currency, &x.Note); err != nil {
			return nil, err
		}
		out = append(out, x)
	}
	return out, rows.Err()
}
