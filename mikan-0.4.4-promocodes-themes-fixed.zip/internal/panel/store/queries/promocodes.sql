-- name: GetPromoCode :one
SELECT * FROM promo_codes WHERE id = ?;

-- name: GetPromoCodeByCode :one
SELECT * FROM promo_codes WHERE code = ?;

-- name: ListPromoCodes :many
SELECT * FROM promo_codes WHERE deleted = 0 ORDER BY id DESC LIMIT ? OFFSET ?;

-- name: CountPromoCodes :one
SELECT COUNT(*) FROM promo_codes WHERE deleted = 0;

-- name: CreatePromoCode :one
INSERT INTO promo_codes
(code,name,description,type,value,currency,starts_at,ends_at,max_uses,per_user_limit,discount_ttl,min_order,max_discount,tariff_ids,first_purchase_only,new_users_only,stackable,enabled,deleted,created_at,created_by)
VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,0,?,?) RETURNING *;

-- name: UpdatePromoCode :one
UPDATE promo_codes SET
code=?,name=?,description=?,type=?,value=?,currency=?,starts_at=?,ends_at=?,max_uses=?,per_user_limit=?,discount_ttl=?,min_order=?,max_discount=?,tariff_ids=?,first_purchase_only=?,new_users_only=?,stackable=?,enabled=? WHERE id=? AND deleted=0 RETURNING *;

-- name: DeletePromoCode :execrows
UPDATE promo_codes SET deleted=1, enabled=0 WHERE id=? AND deleted=0;

-- name: SetPromoEnabled :execrows
UPDATE promo_codes SET enabled=? WHERE id=? AND deleted=0;

-- name: IncrementPromoUse :execrows
UPDATE promo_codes SET used_count=used_count+1 WHERE id=? AND (max_uses IS NULL OR used_count < max_uses) AND deleted=0 AND enabled=1;

-- name: DecrementPromoUse :execrows
UPDATE promo_codes SET used_count=CASE WHEN used_count>0 THEN used_count-1 ELSE 0 END WHERE id=?;

-- name: CountUserPaidPayments :one
SELECT COUNT(*) FROM payments WHERE tg_id=? AND status IN ('paid','applied');

-- name: CountPromoUser :one
SELECT COUNT(*) FROM promo_redemptions WHERE promo_id=? AND ((user_id IS NOT NULL AND user_id=?) OR (user_id IS NULL AND tg_id=?)) AND status IN ('reserved','applied');

-- name: CreatePromoRedemption :one
INSERT INTO promo_redemptions
(promo_id,user_id,tg_id,payment_id,status,redeemed_at,expires_at,days,bytes,discount_amount,original_amount,final_amount,currency,note)
VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?) RETURNING *;

-- name: GetPromoRedemption :one
SELECT * FROM promo_redemptions WHERE id=?;

-- name: GetPromoRedemptionByPayment :one
SELECT * FROM promo_redemptions WHERE payment_id=?;

-- name: ListPromoRedemptions :many
SELECT * FROM promo_redemptions ORDER BY id DESC LIMIT ? OFFSET ?;

-- name: CountPromoRedemptions :one
SELECT COUNT(*) FROM promo_redemptions;

-- name: MarkPromoApplied :execrows
UPDATE promo_redemptions SET status='applied', user_id=COALESCE(?,user_id) WHERE id=? AND status='reserved';

-- name: ReleasePromoRedemption :execrows
UPDATE promo_redemptions SET status='released' WHERE id=? AND status='reserved';

-- name: ReleasePromoByPayment :execrows
UPDATE promo_redemptions SET status='released' WHERE payment_id=? AND status='reserved';

-- name: PromoStats :one
SELECT COUNT(*), COALESCE(SUM(CASE WHEN status='applied' THEN days ELSE 0 END),0), COALESCE(SUM(CASE WHEN status='applied' THEN bytes ELSE 0 END),0), COALESCE(SUM(CASE WHEN status='applied' THEN discount_amount ELSE 0 END),0), COALESCE(SUM(CASE WHEN status='applied' AND payment_id IS NOT NULL THEN 1 ELSE 0 END),0) FROM promo_redemptions;

-- name: ListExpiredPromoPayments :many
SELECT DISTINCT p.id FROM payments p JOIN promo_redemptions r ON r.payment_id=p.id WHERE p.status='expired' AND p.created_at < ? AND r.status='reserved';

-- name: ListPromoRedemptionsByTg :many
SELECT * FROM promo_redemptions WHERE tg_id=? AND status='applied' ORDER BY id DESC LIMIT ?;
