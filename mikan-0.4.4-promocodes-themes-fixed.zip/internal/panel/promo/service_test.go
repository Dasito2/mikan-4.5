package promo

import (
	"context"
	"database/sql"
	"errors"
	"testing"
	"time"

	"mikan/internal/panel/store"
	"mikan/internal/panel/store/db"
)

func newTestStore(t *testing.T) *store.Store {
	t.Helper()
	st, err := store.Open(context.Background(), t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	return st
}
func addUser(t *testing.T, st *store.Store, id int64, tg int64, expires int64) {
	t.Helper()
	ctx := context.Background()
	_, err := st.DB.ExecContext(ctx, `INSERT INTO users(id,name,period_start,sub_token,created_at,updated_at,expires_at) VALUES(?,?,?,?,?,?,?)`, id, "Test", 1, "token-"+string(rune(id)), 1, 1, expires)
	if err != nil {
		t.Fatal(err)
	}
	_, err = st.DB.ExecContext(ctx, `INSERT INTO tg_links(user_id,tg_id,created_at) VALUES(?,?,?)`, id, tg, 1)
	if err != nil {
		t.Fatal(err)
	}
}
func addPromo(t *testing.T, st *store.Store, typ string, val int64, max *int64) *db.PromoCode {
	t.Helper()
	p, err := st.Q.CreatePromoCode(context.Background(), db.CreatePromoCodeParams{Code: "TEST" + typ, Type: typ, Value: val, Currency: "RUB", MaxUses: func() sql.NullInt64 {
		if max == nil {
			return sql.NullInt64{}
		}
		return sql.NullInt64{Int64: *max, Valid: true}
	}(), PerUserLimit: 1, TariffIds: "[]", Enabled: 1, CreatedAt: 1})
	if err != nil {
		t.Fatal(err)
	}
	return &p
}
func TestCheck(t *testing.T) {
	now := time.Unix(1000, 0)
	cases := []struct {
		name string
		p    db.PromoCode
		want error
	}{
		{name: "disabled", p: db.PromoCode{Enabled: 0}, want: ErrInactive},
		{name: "not started", p: db.PromoCode{Enabled: 1, StartsAt: sql.NullInt64{Int64: 1001, Valid: true}}, want: ErrInactive},
		{name: "expired", p: db.PromoCode{Enabled: 1, EndsAt: sql.NullInt64{Int64: 1000, Valid: true}}, want: ErrExpired},
		{name: "exhausted", p: db.PromoCode{Enabled: 1, UsedCount: 2, MaxUses: sql.NullInt64{Int64: 2, Valid: true}}, want: ErrLimit},
		{name: "active", p: db.PromoCode{Enabled: 1}, want: nil},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			if err := check(tc.p, now); !errors.Is(err, tc.want) {
				t.Fatalf("check() = %v, want %v", err, tc.want)
			}
		})
	}
}

func TestNormalize(t *testing.T) {
	if got := Normalize(" welcome 30 "); got != "WELCOME30" {
		t.Fatalf("got %q", got)
	}
}
func TestReserveDiscountAndLimit(t *testing.T) {
	st := newTestStore(t)
	defer st.Close()
	ctx := context.Background()
	max := int64(1)
	p := addPromo(t, st, "percent", 25, &max)
	s := New(st, func() time.Time { return time.Unix(1000, 0) })
	d, err := s.ReserveDiscount(ctx, st.Q, 10, 0, 7, 1000, "RUB", p.Code, 42)
	if err != nil {
		t.Fatal(err)
	}
	if d.Amount != 250 || d.Final != 750 {
		t.Fatalf("discount: %+v", d)
	}
	if _, err := s.ReserveDiscount(ctx, st.Q, 11, 0, 7, 1000, "RUB", p.Code, 43); !errors.Is(err, ErrLimit) {
		t.Fatalf("expected limit, got %v", err)
	}
	if err := s.ReleasePayment(ctx, 42); err != nil {
		t.Fatal(err)
	}
	if _, err := s.ReserveDiscount(ctx, st.Q, 11, 0, 7, 1000, "RUB", p.Code, 43); err != nil {
		t.Fatalf("released reservation should free use: %v", err)
	}
}
func TestRedeemTrafficAndDays(t *testing.T) {
	st := newTestStore(t)
	defer st.Close()
	ctx := context.Background()
	now := time.Unix(2000, 0)
	addUser(t, st, 1, 77, now.Add(24*time.Hour).Unix())
	s := New(st, func() time.Time { return now })
	p := addPromo(t, st, "traffic", 2*domainGiBForTest, nil)
	if _, err := s.RedeemBonus(ctx, 77, 1, p.Code); err != nil {
		t.Fatal(err)
	}
	gs, err := st.Q.ListUserGrants(ctx, 1)
	if err != nil || len(gs) != 1 || gs[0].Bytes != 2*domainGiBForTest {
		t.Fatalf("grant: %v %+v", err, gs)
	}
	p2 := addPromo(t, st, "days", 30, nil)
	if _, err := s.RedeemBonus(ctx, 77, 1, p2.Code); err != nil {
		t.Fatal(err)
	}
	u, err := st.Q.GetUser(ctx, 1)
	if err != nil {
		t.Fatal(err)
	}
	if u.ExpiresAt.Int64 != now.Add(31*24*time.Hour).Unix() {
		t.Fatalf("expiry %d", u.ExpiresAt.Int64)
	}
}

const domainGiBForTest = int64(1) << 30
