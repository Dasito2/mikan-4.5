package promo

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"strconv"
	"strings"
	"time"

	"mikan/internal/panel/domain"
	"mikan/internal/panel/store"
	"mikan/internal/panel/store/db"
)

var (
	ErrNotFound       = errors.New("promo_not_found")
	ErrInactive       = errors.New("promo_inactive")
	ErrExpired        = errors.New("promo_expired")
	ErrLimit          = errors.New("promo_limit")
	ErrUserLimit      = errors.New("promo_user_limit")
	ErrTariff         = errors.New("promo_tariff")
	ErrMinimum        = errors.New("promo_minimum")
	ErrNewUser        = errors.New("promo_new_user")
	ErrFirstPurchase  = errors.New("promo_first_purchase")
	ErrCurrency       = errors.New("promo_currency")
	ErrAlreadyApplied = errors.New("promo_already_applied")
	ErrSubscription   = errors.New("promo_subscription_required")
	ErrNoExpiry       = errors.New("promo_no_expiry")
)

type Service struct {
	Store   *store.Store
	Now     func() time.Time
	Changed func()
}

type Discount struct {
	PromoID      int64
	RedemptionID int64
	Code         string
	Amount       int64
	Original     int64
	Final        int64
	Currency     string
}

func New(st *store.Store, now func() time.Time) *Service {
	if now == nil {
		now = time.Now
	}
	return &Service{Store: st, Now: now}
}

func Normalize(code string) string {
	return strings.ToUpper(strings.Join(strings.Fields(code), ""))
}

func check(p db.PromoCode, now time.Time) error {
	if p.Deleted != 0 || p.Enabled == 0 {
		return ErrInactive
	}
	n := now.Unix()
	if p.StartsAt.Valid && n < p.StartsAt.Int64 {
		return ErrInactive
	}
	if p.EndsAt.Valid && n >= p.EndsAt.Int64 {
		return ErrExpired
	}
	if p.MaxUses.Valid && p.UsedCount >= p.MaxUses.Int64 {
		return ErrLimit
	}
	return nil
}

func active(p db.PromoCode, now time.Time) error {
	return check(p, now)
}

func tariffs(p db.PromoCode) (map[int64]bool, error) {
	out := map[int64]bool{}
	if strings.TrimSpace(p.TariffIds) == "" || p.TariffIds == "[]" {
		return out, nil
	}
	var ids []int64
	if err := json.Unmarshal([]byte(p.TariffIds), &ids); err != nil {
		return nil, err
	}
	for _, id := range ids {
		if id > 0 {
			out[id] = true
		}
	}
	return out, nil
}

func (s *Service) load(ctx context.Context, code string) (db.PromoCode, error) {
	p, err := s.Store.Q.GetPromoCodeByCode(ctx, Normalize(code))
	if errors.Is(err, sql.ErrNoRows) {
		return db.PromoCode{}, ErrNotFound
	}
	return p, err
}

func (s *Service) checkUser(ctx context.Context, q *db.Queries, p db.PromoCode, tgID, userID int64, now time.Time) error {
	if err := active(p, now); err != nil {
		return err
	}
	if p.NewUsersOnly != 0 {
		n, err := q.CountTgLinksOf(ctx, tgID)
		if err != nil {
			return err
		}
		if n > 0 {
			return ErrNewUser
		}
	}
	if p.FirstPurchaseOnly != 0 {
		n, err := q.CountUserPaidPayments(ctx, tgID)
		if err != nil {
			return err
		}
		if n > 0 {
			return ErrFirstPurchase
		}
	}
	n, err := q.CountPromoUser(ctx, p.ID, userID, tgID)
	if err != nil {
		return err
	}
	if n >= p.PerUserLimit {
		return ErrUserLimit
	}
	return nil
}

// Validate returns the current code and a human-readable machine status without consuming it.
// It is used by the Mini App before the actual action/payment.
func (s *Service) Validate(ctx context.Context, tgID, userID, tariffID, amount int64, currency, code string) (db.PromoCode, error) {
	p, err := s.load(ctx, code)
	if err != nil {
		return p, err
	}
	if err := s.checkUser(ctx, s.Store.Q, p, tgID, userID, s.Now()); err != nil {
		return p, err
	}
	if p.Type == "percent" || p.Type == "fixed" {
		if tariffID > 0 {
			ids, err := tariffs(p)
			if err != nil {
				return p, err
			}
			if len(ids) > 0 && !ids[tariffID] {
				return p, ErrTariff
			}
		}
		if amount > 0 && p.MinOrder > 0 && amount < p.MinOrder {
			return p, ErrMinimum
		}
		if currency != "" && p.Currency != "" && p.Currency != currency {
			return p, ErrCurrency
		}
	}
	return p, nil
}

func discountAmount(p db.PromoCode, original int64) int64 {
	if original <= 0 {
		return 0
	}
	var d int64
	if p.Type == "percent" {
		d = (original * p.Value) / 100
		if d < 0 {
			d = 0
		}
	} else {
		d = p.Value
	}
	if p.MaxDiscount > 0 && d > p.MaxDiscount {
		d = p.MaxDiscount
	}
	if d > original {
		d = original
	}
	return d
}

// ReserveDiscount atomically reserves one use and records the discount alongside the payment.
func (s *Service) ReserveDiscount(ctx context.Context, q *db.Queries, tgID, userID, tariffID, amount int64, currency, code string, paymentID int64) (Discount, error) {
	if strings.TrimSpace(code) == "" {
		return Discount{}, nil
	}
	p, err := q.GetPromoCodeByCode(ctx, Normalize(code))
	if errors.Is(err, sql.ErrNoRows) {
		return Discount{}, ErrNotFound
	}
	if err != nil {
		return Discount{}, err
	}
	if err := s.checkUser(ctx, q, p, tgID, userID, s.Now()); err != nil {
		return Discount{}, err
	}
	ids, err := tariffs(p)
	if err != nil {
		return Discount{}, err
	}
	if len(ids) > 0 && !ids[tariffID] {
		return Discount{}, ErrTariff
	}
	if p.MinOrder > 0 && amount < p.MinOrder {
		return Discount{}, ErrMinimum
	}
	if p.Currency != "" && p.Currency != currency {
		return Discount{}, ErrCurrency
	}
	d := discountAmount(p, amount)
	if d <= 0 {
		return Discount{}, ErrMinimum
	}
	n, err := q.IncrementPromoUse(ctx, p.ID)
	if err != nil {
		return Discount{}, err
	}
	if n != 1 {
		return Discount{}, ErrLimit
	}
	expires := sql.NullInt64{}
	if p.DiscountTtl > 0 {
		expires = sql.NullInt64{Int64: s.Now().Add(time.Duration(p.DiscountTtl) * time.Second).Unix(), Valid: true}
	}
	r, err := q.CreatePromoRedemption(ctx, db.CreatePromoRedemptionParams{
		PromoID: p.ID, UserID: sql.NullInt64{Int64: userID, Valid: userID != 0}, TgID: tgID, PaymentID: sql.NullInt64{Int64: paymentID, Valid: paymentID != 0},
		Status: "reserved", RedeemedAt: s.Now().Unix(), ExpiresAt: expires, DiscountAmount: d, OriginalAmount: amount, FinalAmount: amount - d, Currency: currency, Note: p.Description,
	})
	if err != nil {
		_ = q.DecrementPromoUse(ctx, p.ID)
		return Discount{}, err
	}
	return Discount{PromoID: p.ID, RedemptionID: r.ID, Code: p.Code, Amount: d, Original: amount, Final: amount - d, Currency: currency}, nil
}

// RedeemBonus applies a days or traffic reward atomically and writes its history.
func (s *Service) RedeemBonus(ctx context.Context, tgID, userID int64, code string) (db.PromoRedemption, error) {
	if userID == 0 {
		return db.PromoRedemption{}, ErrSubscription
	}
	var out db.PromoRedemption
	err := s.Store.Tx(ctx, func(q *db.Queries) error {
		p, err := q.GetPromoCodeByCode(ctx, Normalize(code))
		if errors.Is(err, sql.ErrNoRows) {
			return ErrNotFound
		}
		if err != nil {
			return err
		}
		if err := s.checkUser(ctx, q, p, tgID, userID, s.Now()); err != nil {
			return err
		}
		if p.Type != "days" && p.Type != "traffic" {
			return errors.New("promo_not_bonus")
		}
		u, err := q.GetUser(ctx, userID)
		if err != nil {
			return err
		}
		now := s.Now()
		switch p.Type {
		case "days":
			if !u.ExpiresAt.Valid {
				return ErrNoExpiry
			}
			base := now.Unix()
			if u.ExpiresAt.Int64 > base {
				base = u.ExpiresAt.Int64
			}
			next := base + p.Value*int64(24*time.Hour/time.Second)
			_, err = q.UpdateUser(ctx, db.UpdateUserParams{
				Name: u.Name, Contact: u.Contact, Note: u.Note, Tags: u.Tags, Status: u.Status, TariffID: u.TariffID, TrafficLimit: u.TrafficLimit, DeviceLimit: u.DeviceLimit,
				ResetStrategy: u.ResetStrategy, PeriodDays: u.PeriodDays, PeriodStart: u.PeriodStart,
				ExpiresAt: sql.NullInt64{Int64: next, Valid: true}, Inbounds: u.Inbounds, BillingDay: u.BillingDay, UpdatedAt: now.Unix(), ID: u.ID,
			})
			if err != nil {
				return err
			}
		case "traffic":
			if p.Value < domain.MinGrantBytes {
				return errors.New("promo_traffic_too_small")
			}
			// Bonus traffic uses the native grant mechanism and remains until consumed.
			g, err := q.CreateTrafficGrant(ctx, db.CreateTrafficGrantParams{UserID: userID, PoolID: sql.NullInt64{}, Bytes: p.Value, Remaining: p.Value, Lifetime: domain.LifetimeUsed, ExpiresAt: sql.NullInt64{}, Source: domain.SourceAdmin, PaymentID: sql.NullInt64{}, PackageID: sql.NullInt64{}, Note: "promo:" + p.Code, CreatedAt: now.Unix()})
			if err != nil {
				return err
			}
			out.Bytes = g.Bytes
		}
		n, err := q.IncrementPromoUse(ctx, p.ID)
		if err != nil {
			return err
		}
		if n != 1 {
			return ErrLimit
		}
		days := int64(0)
		if p.Type == "days" {
			days = p.Value
		}
		bytes := p.Value
		if p.Type == "days" {
			bytes = 0
		}
		r, err := q.CreatePromoRedemption(ctx, db.CreatePromoRedemptionParams{PromoID: p.ID, UserID: sql.NullInt64{Int64: userID, Valid: true}, TgID: tgID, Status: "applied", RedeemedAt: now.Unix(), Days: days, Bytes: bytes, Note: p.Description})
		out = r
		return err
	})
	if err == nil && s.Changed != nil {
		s.Changed()
	}
	return out, err
}

func (s *Service) GetPaymentRedemption(ctx context.Context, paymentID int64) (db.PromoRedemption, error) {
	return s.Store.Q.GetPromoRedemptionByPayment(ctx, paymentID)
}

func (s *Service) ReleasePayment(ctx context.Context, paymentID int64) error {
	return s.Store.Tx(ctx, func(q *db.Queries) error {
		r, err := q.GetPromoRedemptionByPayment(ctx, paymentID)
		if errors.Is(err, sql.ErrNoRows) {
			return nil
		}
		if err != nil {
			return err
		}
		if r.Status != "reserved" {
			return nil
		}
		if _, err := q.ReleasePromoRedemption(ctx, r.ID); err != nil {
			return err
		}
		return q.DecrementPromoUse(ctx, r.PromoID)
	})
}

func (s *Service) ReleaseExpired(ctx context.Context, before int64) error {
	rows, err := s.Store.Q.ListExpiredPromoPayments(ctx, before)
	if err != nil {
		return err
	}
	for _, id := range rows {
		if err := s.ReleasePayment(ctx, id); err != nil {
			return err
		}
	}
	return nil
}

func (s *Service) ApplyPayment(ctx context.Context, q *db.Queries, paymentID, userID int64) error {
	r, err := q.GetPromoRedemptionByPayment(ctx, paymentID)
	if errors.Is(err, sql.ErrNoRows) {
		return nil
	}
	if err != nil {
		return err
	}
	if r.Status != "reserved" {
		return nil
	}
	n, err := q.MarkPromoApplied(ctx, sql.NullInt64{Int64: userID, Valid: userID != 0}, r.ID)
	if err != nil {
		return err
	}
	if n != 1 {
		return ErrAlreadyApplied
	}
	return nil
}

func (s *Service) CodeForPayment(ctx context.Context, paymentID int64) (string, error) {
	r, err := s.Store.Q.GetPromoRedemptionByPayment(ctx, paymentID)
	if err != nil {
		return "", err
	}
	p, err := s.Store.Q.GetPromoCode(ctx, r.PromoID)
	if err != nil {
		return "", err
	}
	return p.Code, nil
}

func ParseInt(v string) (int64, error)   { return strconv.ParseInt(strings.TrimSpace(v), 10, 64) }
func Field(name string, err error) error { return fmt.Errorf("%s: %w", name, err) }
