package api

import (
	"testing"
	"time"
)

func TestValidatePromoBody(t *testing.T) {
	now := time.Unix(2_000_000_000, 0)
	base := PromoBody{Code: "SAVE", Type: "percent", Value: 20, PerUserLimit: 1}
	cases := []struct {
		name string
		in   PromoBody
		used int64
		want string
	}{
		{name: "past end", in: func() PromoBody { x := base; v := now.Unix() - 1; x.EndsAt = &v; return x }(), want: "ends_at_past"},
		{name: "max uses below used", in: func() PromoBody { x := base; v := int64(2); x.MaxUses = &v; return x }(), used: 3, want: "max_uses_below_used"},
		{name: "bad percent", in: func() PromoBody { x := base; x.Value = 101; return x }(), want: "bad_percent"},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			err := validatePromoBody(tc.in, now, tc.used)
			if err == nil || err.Error() != tc.want {
				t.Fatalf("validatePromoBody() = %v, want %s", err, tc.want)
			}
		})
	}
}
